# Pub Darts Night Android v1

Android Studio project wrapping the working v46.1 scorer in a native WebView.

## Native voice input
The app requests RECORD_AUDIO permission and includes an Android speech-recognition bridge:
`nativeVoiceInput(targetId, mode)` where mode is `text` or `players`.

The existing browser speech recognition remains in the HTML. To make any microphone button use the native Android recognizer, call:
`nativeVoiceInput('ELEMENT_ID','text')`
or
`nativeVoiceInput('ELEMENT_ID','players')`.

## Build
Open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s).
