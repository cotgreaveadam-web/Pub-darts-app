plugins { id("com.android.application") }

android {
    namespace = "uk.co.pubdartsnight"
    compileSdk = 35

    defaultConfig {
        applicationId = "uk.co.pubdartsnight"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
}
