# Pub Darts Night Android v2 FIXED

Fixes:
- Adds the Kotlin Android Gradle plugin.
- Aligns all Kotlin runtime dependencies to 1.8.22 to prevent duplicate-class errors.
- Includes native Android speech-recognition bridge fixes from v1 FIXED.
- Includes a GitHub Actions workflow configured for PubDartsNight_Android_v2_FIXED.zip.

Important: if this ZIP is stored in a GitHub repository, the repository's active .github/workflows/android.yml (or equivalent workflow file) must also be updated to unzip this v2 ZIP. A workflow inside a ZIP does not become active automatically.
