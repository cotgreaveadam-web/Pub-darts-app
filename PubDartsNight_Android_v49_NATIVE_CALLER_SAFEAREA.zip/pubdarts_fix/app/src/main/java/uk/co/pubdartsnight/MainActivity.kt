package uk.co.pubdartsnight

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingTarget = ""
    private var pendingMode = "text"

    private val voiceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
        if (text.isNotBlank() && pendingTarget.isNotBlank()) {
            val js = "window.PubDartsNativeVoiceResult(${JSONObject.quote(text)},${JSONObject.quote(pendingTarget)},${JSONObject.quote(pendingMode)});"
            webView.evaluateJavascript(js, null)
        }
    }

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchRecognizer() else Toast.makeText(this, "Microphone permission is needed for voice input.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        webView = WebView(this)
        setContentView(webView)
        ViewCompat.setOnApplyWindowInsetsListener(webView) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(VoiceBridge(), "AndroidVoice")
        webView.addJavascriptInterface(CallerBridge(), "AndroidCaller")
        webView.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }


    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val engine = tts ?: return
        val result = engine.setLanguage(Locale.UK)
        ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        if (ttsReady) {
            // Prefer an installed UK English voice; favour a male/George voice when the engine exposes one.
            val ukVoices = engine.voices?.filter { it.locale?.language == "en" && it.locale?.country == "GB" }.orEmpty()
            val preferred = ukVoices.firstOrNull { it.name.contains("george", true) }
                ?: ukVoices.firstOrNull { it.name.contains("male", true) }
                ?: ukVoices.firstOrNull { !it.isNetworkConnectionRequired }
                ?: ukVoices.firstOrNull()
            if (preferred != null) engine.voice = preferred
            engine.setSpeechRate(0.95f)
            engine.setPitch(0.90f)
        }
        runOnUiThread {
            webView.evaluateJavascript("window.PubDartsNativeCallerReady && window.PubDartsNativeCallerReady(${ttsReady});", null)
        }
    }

    inner class CallerBridge {
        @JavascriptInterface
        fun isReady(): Boolean = ttsReady

        @JavascriptInterface
        fun speak(text: String, shout: Boolean) {
            runOnUiThread {
                val engine = tts ?: return@runOnUiThread
                if (!ttsReady) return@runOnUiThread
                engine.setSpeechRate(if (shout) 0.88f else 0.98f)
                engine.setPitch(if (shout) 0.84f else 0.90f)
                engine.speak(text, TextToSpeech.QUEUE_ADD, null, "pubdarts-${System.nanoTime()}")
            }
        }

        @JavascriptInterface
        fun stop() { runOnUiThread { tts?.stop() } }
    }

    inner class VoiceBridge {
        @JavascriptInterface
        fun startVoiceInput(targetId: String, mode: String) {
            runOnUiThread {
                pendingTarget = targetId
                pendingMode = mode
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    launchRecognizer()
                } else {
                    micPermission.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
        }
    }

    private fun launchRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak venue, team or player name")
        }
        try {
            voiceLauncher.launch(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Speech recognition is not available on this device.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        webView.removeJavascriptInterface("AndroidVoice")
        webView.removeJavascriptInterface("AndroidCaller")
        tts?.stop()
        tts?.shutdown()
        webView.destroy()
        super.onDestroy()
    }
}
